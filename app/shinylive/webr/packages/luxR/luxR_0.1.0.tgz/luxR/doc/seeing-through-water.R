## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(
  message = FALSE, warning = FALSE,
  fig.width = 7, fig.height = 4
)

## ----load---------------------------------------------------------------------
library(luxR)

## ----surface------------------------------------------------------------------
sp    <- solar_irradiance("clear_noon")   # W/m2/nm, above surface
lam   <- sp$wavelength

tau   <- surface_transmittance(angle = 30)            # sun 30 deg from vertical
E_sub <- sp$irradiance * tau                          # just below the surface
round(tau, 3)

## ----propagate----------------------------------------------------------------
depth  <- 10                                          # metres
at_10m <- light_at_depth("clear_noon", "II", depth,
                         wavelength_policy = "trim",
                         surface_source = "direct", surface_angle = 30)
lam_depth <- at_10m$lambda
supported <- lam >= min(lam_depth) & lam <= max(lam_depth)
E_10m  <- at_10m$irradiance
E_sub <- E_sub[supported]
lam <- lam_depth

plot(lam, E_sub, type = "l", col = "goldenrod", lwd = 2,
     xlab = "Wavelength (nm)", ylab = "Irradiance (W/m2/nm)",
     main = "Surface vs 10 m (Jerlov II)")
lines(lam, E_10m, col = "steelblue4", lwd = 2)
legend("topright", c("Just below surface", "10 m"),
       col = c("goldenrod", "steelblue4"), lwd = 2, bty = "n")

## ----capture------------------------------------------------------------------
viewer <- "Danio rerio"                               # a tetrachromat
recs   <- unique(subset(species_sensitivities,
                        species == viewer)$receptor)

lam_s  <- seq(300, 750, by = 1)
catch  <- sapply(recs, function(r) {
  row <- subset(species_sensitivities,
                species == viewer & receptor == r)
  tmpl <- govardovskii_template(lam_s, row$lambda_max[1], row$chromophore[1])
  S    <- receptor_absorptance(tmpl, optical_density = 0.4)   # self-screening
  quantum_catch(E_10m, lam, S, input_unit = "W/m2/nm")
})
round(catch)

## ----contrast-----------------------------------------------------------------
grey <- rep(0.30, length(lam))
red  <- 0.20 + 0.25 * exp(-((lam - 625) / 35)^2)

ic <- inherent_contrast(red, grey, E_10m, lam, species = viewer)
ic

## ----detect-------------------------------------------------------------------
c_beam <- beam_attenuation(absorption = 0.20, scattering = 0.12)   # 1/m
Kd_ref <- jerlov_Kd("II", lambda = 490)

d <- detectability(red, grey, E_10m, lam, Kd = Kd_ref,
                   beam_c = c_beam, species = viewer)
d

## ----detect-plot--------------------------------------------------------------
plot(d)

## ----looking-up---------------------------------------------------------------
detection_range(red, grey, E_10m, lam, Kd = Kd_ref, beam_c = c_beam,
                species = viewer, channel = "achromatic",
                direction = "up")$achromatic

## ----spectral-path------------------------------------------------------------
Kd_lambda <- jerlov_Kd("II", lambda = lam)
c_lambda  <- 1.5 * Kd_lambda
veil      <- grey * irradiance2radiance(E_10m, geometry = "lambertian")

d_spectral <- detectability(
  red, grey, E_10m, lam,
  Kd = Kd_lambda,
  beam_c = c_lambda,
  species = viewer,
  model = "spectral_path",
  veiling = veil,
  max_distance = 50,
  search_points = 201
)
d_spectral

