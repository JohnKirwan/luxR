## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(
  message = FALSE, warning = FALSE,
  fig.width = 7, fig.height = 4
)

## ----load---------------------------------------------------------------------
library(luxR)

x0m   <- from_naples("0m")          # umol/m2/s/nm
x0m_W <- convert_unit(x0m, "W/m2/nm")
x0m_W

## ----unit-table---------------------------------------------------------------
unit_table <- data.frame(
  Quantity = c(
    "Integrated energy flux in PAR window (W m⁻²)",
    "Photon flux — PAR (µmol m⁻² s⁻¹)",
    "Photopic illuminance (lux)",
    "Scotopic illuminance (scotopic lux)"
  ),
  Value = c(
    round(sum(x0m_W$E[x0m_W$lambda >= 400 &
                      x0m_W$lambda <= 700]) * x0m_W$binwidth, 1),
    round(par_irradiance(x0m_W), 1),
    round(irradiance2lux(x0m_W), 0),
    round(scotopic_lux(x0m_W), 0)
  )
)
knitr::kable(unit_table)

## ----propagate----------------------------------------------------------------
x0m_Jerlov <- x0m_W[350, 700]
lam   <- x0m_Jerlov$lambda
Kd_II <- jerlov_Kd("II", lam)
specs <- propagate_spectrum(x0m_Jerlov, Kd_II, from = 0,
                            to = c(0, 5, 10, 20, 50))

## ----depth-table--------------------------------------------------------------
depth_table <- data.frame(
  depth_m  = c(0, 5, 10, 20, 50),
  PAR_umol = round(sapply(specs, par_irradiance), 1),
  lux      = round(sapply(specs, irradiance2lux), 0)
)
knitr::kable(depth_table,
             col.names = c("Depth (m)",
                           "PAR (µmol m⁻² s⁻¹)",
                           "Photopic illuminance (lux)"))

## ----pigments-----------------------------------------------------------------
sws_df <- species_LEF("Danio rerio", receptor = "S-cone", lambda = lam)
mws_df <- species_LEF("Danio rerio", receptor = "M-cone", lambda = lam)
lws_df <- species_LEF("Danio rerio", receptor = "L-cone", lambda = lam)

plot(sws_df$lambda, sws_df$S, type = "l", col = "blue",
     xlab = "Wavelength (nm)", ylab = "Normalised absorbance",
     main = "Zebrafish (Danio rerio) cone sensitivities",
     ylim = c(0, 1))
lines(mws_df$lambda, mws_df$S, col = "green3")
lines(lws_df$lambda, lws_df$S, col = "red3")
legend("topright",
       legend = c("S-cone (415 nm)", "M-cone (480 nm)", "L-cone (561 nm)"),
       col = c("blue", "green3", "red3"), lty = 1)

## ----quantum-catch------------------------------------------------------------
qc_list <- lapply(specs, function(s) {
  data.frame(
    S = quantum_catch(s$E, s$lambda, sws_df,
                      input_unit = "W/m2/nm", binwidth = s$binwidth),
    M = quantum_catch(s$E, s$lambda, mws_df,
                      input_unit = "W/m2/nm", binwidth = s$binwidth),
    L = quantum_catch(s$E, s$lambda, lws_df,
                      input_unit = "W/m2/nm", binwidth = s$binwidth)
  )
})
qc_df         <- do.call(rbind, qc_list)
qc_df$depth_m <- c(0, 5, 10, 20, 50)
qc_df$M_L     <- round(qc_df$M / qc_df$L, 3)

knitr::kable(qc_df[, c("depth_m", "S", "M", "L", "M_L")],
             digits = 2,
             col.names = c("Depth (m)", "S-cone catch",
                           "M-cone catch", "L-cone catch", "M/L ratio"))

## ----reflectances-------------------------------------------------------------
grey_R <- lux_spectrum(rep(0.3, length(lam)), lam,
                       quantity = "reflectance", unit = "dimensionless")
red_E  <- 0.2 + 0.25 * exp(-((lam - 625) / 35)^2)
red_R  <- lux_spectrum(red_E, lam,
                       quantity = "reflectance", unit = "dimensionless")

plot(grey_R$lambda, grey_R$E, type = "l", col = "grey50",
     ylim = c(0, 0.6),
     xlab = "Wavelength (nm)", ylab = "Reflectance",
     main = "Substrate reflectance spectra")
lines(red_R$lambda, red_R$E, col = "firebrick")
legend("topright", legend = c("Grey (0.3)", "Red (625 nm peak)"),
       col = c("grey50", "firebrick"), lty = 1)

## ----radiance-----------------------------------------------------------------
rad_grey_0m  <- reflectance_to_radiance(grey_R, specs[["0"]])
rad_red_0m   <- reflectance_to_radiance(red_R,  specs[["0"]])
rad_grey_20m <- reflectance_to_radiance(grey_R, specs[["20"]])
rad_red_20m  <- reflectance_to_radiance(red_R,  specs[["20"]])

ylim_rad <- range(c(rad_red_0m$E, rad_red_20m$E,
                    rad_grey_0m$E, rad_grey_20m$E))
plot(rad_red_0m$lambda, rad_red_0m$E, type = "l", col = "firebrick",
     ylim = ylim_rad,
     xlab = "Wavelength (nm)",
     ylab = expression("Radiance (W m"^{-2}~"nm"^{-1}*")"),
     main = "Substrate radiances at surface vs 20 m")
lines(rad_grey_0m$lambda,  rad_grey_0m$E,  col = "grey50")
lines(rad_red_20m$lambda,  rad_red_20m$E,  col = "firebrick", lty = 2)
lines(rad_grey_20m$lambda, rad_grey_20m$E, col = "grey50",    lty = 2)
legend("topright",
       legend = c("Red (0 m)", "Grey (0 m)",
                  "Red (20 m)", "Grey (20 m)"),
       col = c("firebrick", "grey50", "firebrick", "grey50"),
       lty = c(1, 1, 2, 2))

## ----colour-jnd---------------------------------------------------------------
depths     <- c(0, 5, 10, 20, 50)
depth_keys <- as.character(depths)

jnd_vals <- sapply(depth_keys, function(d) {
  r1 <- reflectance_to_radiance(grey_R, specs[[d]])
  r2 <- reflectance_to_radiance(red_R,  specs[[d]])
  colour_jnd(
    stim1    = r1$E,
    stim2    = r2$E,
    lambda   = r1$lambda,
    species  = "Danio rerio",
    receptor = c("S-cone", "M-cone", "L-cone"),
    noise    = 0.05,
    binwidth = r1$binwidth
  )
})

jnd_table <- data.frame(depth_m = depths, JND = round(jnd_vals, 2))
knitr::kable(jnd_table,
             col.names = c("Depth (m)", "ΔS (JND)"))

## ----jnd-plot-----------------------------------------------------------------
plot(jnd_table$depth_m, jnd_table$JND, type = "b", pch = 16,
     xlab = "Depth (m)",
     ylab = expression(Delta * S ~ (JND)),
     main = "Colour discrimination vs depth")
abline(h = 1, lty = 2, col = "red")
text(35, 1.3, "discrimination\nthreshold", col = "red", cex = 0.85)

## ----threshold----------------------------------------------------------------
fail_idx <- which(jnd_table$JND < 1)
if (length(fail_idx) > 0) {
  cat(sprintf(
    "Discrimination fails (JND < 1) at %d m depth.\n",
    jnd_table$depth_m[fail_idx[1]]
  ))
} else {
  cat("JND remains above 1 at all modelled depths.\n")
}

## ----pavo-validation, eval = requireNamespace("pavo", quietly = TRUE)---------
library(pavo)

lam <- 300:750
s1  <- approx(solar_spectra$clear_noon$wavelength,
              solar_spectra$clear_noon$irradiance, lam, rule = 2)$y
s2  <- approx(solar_spectra$underwater_10m$wavelength,
              solar_spectra$underwater_10m$irradiance, lam, rule = 2)$y
w   <- 0.05

pavo_dS <- function(species) {
  members <- species_channels[
    species_channels$species == species &
      species_channels$channel_role == "chromatic" &
      species_channels$is_default,
  ]
  species_rows <- species_sensitivities[
    species_sensitivities$species == species,
  ]
  recs <- species_rows[match(members$receptor, species_rows$receptor), ]
  S <- sapply(seq_len(nrow(recs)), function(i)
    govardovskii_template(lam, recs$lambda_max[i], recs$chromophore[i])$S)
  colnames(S) <- make.unique(recs$receptor)
  vm <- vismodel(as.rspec(data.frame(wl = lam, s1 = s1, s2 = s2), lim = range(lam)),
                 visual = as.rspec(data.frame(wl = lam, S), lim = range(lam)),
                 illum = lam, qcatch = "Qi", vonkries = FALSE,
                 relative = FALSE, achromatic = "none")
  coldist(vm, noise = "neural", n = rep(1, nrow(recs)),
          weber = w, weber.ref = 1, achromatic = FALSE)$dS[1]
}

species <- c("Homo sapiens", "Apis mellifera", "Danio rerio")
cmp <- data.frame(
  species = species,
  luxR    = sapply(species, function(sp)
              colour_jnd(s1, s2, lambda = lam, species = sp, noise = w)),
  pavo    = sapply(species, function(sp) suppressMessages(pavo_dS(sp)))
)
cmp$abs_diff <- abs(cmp$luxR - cmp$pavo)
knitr::kable(cmp, digits = c(0, 6, 6, 14),
             col.names = c("Species", "luxR ΔS", "pavo ΔS", "|difference|"))

## ----pavo-interop, eval = requireNamespace("pavo", quietly = TRUE)------------
library(pavo)

# luxR: the downwelling light field at 15 m (this becomes pavo's illuminant)
Ld  <- light_at_depth("clear_noon", "II", depth = 15,
                      wavelength_policy = "trim")

# Two object reflectances, bridged into pavo via as_rspec() (interpolated to 1 nm)
lam   <- Ld$lambda
gauss <- function(centre) 0.2 + 0.25 * exp(-((lam - centre) / 35)^2)
refl  <- as_rspec(list(
  red_substrate  = as_lux_spectrum(
    gauss(625), lambda = lam,
    quantity = "reflectance", unit = "dimensionless"
  ),
  grey_substrate = as_lux_spectrum(
    rep(0.3, length(lam)), lambda = lam,
    quantity = "reflectance", unit = "dimensionless"
  )
), lim = c(300, 700))   # match pavo's built-in honeybee visual system

# Put luxR's light field on the rspec's (1 nm) grid so it can serve as the illuminant
illum <- approx(Ld$lambda, Ld$irradiance, refl$wl, rule = 2)$y

# pavo: model a honeybee viewing those substrates UNDER luxR's underwater light
vm <- vismodel(refl, visual = "apis", illum = illum,
               qcatch = "Qi", relative = FALSE)
coldist(vm, n = c(1, 1, 1), achromatic = FALSE)[, c("patch1", "patch2", "dS")]

## ----cv-interop, eval = requireNamespace("colourvision", quietly = TRUE)------
library(colourvision)

lam <- 300:700

# luxR: the downwelling light field at 15 m in Jerlov II water becomes
# colourvision's illuminant I.
Ld <- light_at_depth("clear_noon", "II", depth = 15, wavelength_policy = "trim")
I <- as_colourvision(
  as_lux_spectrum(
    stats::approx(Ld$lambda, Ld$irradiance, lam, rule = 2)$y,
    lambda = lam, quantity = "irradiance", unit = "W/m2/nm"
  ),
  name = "I")

# Two object reflectances as R1 / R2, flat background Rb.
R1 <- data.frame(wl = lam, R = 0.2 + 0.25 * exp(-((lam - 550) / 30)^2))
R2 <- data.frame(wl = lam, R = 0.2 + 0.25 * exp(-((lam - 600) / 30)^2))
Rb <- data.frame(wl = lam, R = rep(0.1, length(lam)))

# luxR's own receptors as colourvision's C (photon-weighted).
C <- species_sensitivity_matrix("Apis mellifera", lambda = lam)

RNLmodel(model = "log", R1 = R1, R2 = R2, Rb = Rb, I = I, C = C,
         noise = TRUE, e = rep(0.05, ncol(C) - 1),
         interpolate = FALSE, nm = lam)[["deltaS"]]

