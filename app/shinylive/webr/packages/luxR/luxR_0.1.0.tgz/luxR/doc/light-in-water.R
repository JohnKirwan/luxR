## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(
  message = FALSE, warning = FALSE,
  fig.width = 7, fig.height = 4
)

## ----load---------------------------------------------------------------------
library(luxR)

x0m  <- from_naples("0m")
x5m  <- from_naples("5m")
x10m <- from_naples("10m")

x0m

## ----plot-surface-------------------------------------------------------------
plot(x0m, main = "Surface irradiance — Naples coastal site")

## ----convert------------------------------------------------------------------
x0m_W  <- convert_unit(x0m,  "W/m2/nm")
x5m_W  <- convert_unit(x5m,  "W/m2/nm")
x10m_W <- convert_unit(x10m, "W/m2/nm")

x0m_W

## ----photobiology-validation, eval = requireNamespace("photobiology", quietly = TRUE)----
lam <- seq(300, 800, by = 50)
pb  <- photobiology::e2quantum_multipliers(lam, molar = FALSE)
tab <- data.frame(
  wavelength_nm = lam,
  ratio         = W2photon(1, lam) / pb,
  rel_diff      = abs(W2photon(1, lam) - pb) / pb
)
knitr::kable(tab, digits = c(0, 12, 16),
             col.names = c("λ (nm)", "luxR / photobiology", "rel. difference"))

## ----par----------------------------------------------------------------------
par_table <- data.frame(
  depth_m  = c(0, 5, 10),
  PAR_umol = c(par_irradiance(x0m_W),
               par_irradiance(x5m_W),
               par_irradiance(x10m_W))
)
knitr::kable(par_table, digits = 1,
             col.names = c("Depth (m)", "PAR (µmol m⁻² s⁻¹)"))

## ----fit-kd-------------------------------------------------------------------
Kd_meas <- fit_Kd(x0m_W, 0, x10m_W, 10)

plot(x0m_W$lambda, Kd_meas, type = "l",
     xlab = "Wavelength (nm)",
     ylab = expression(K[d] ~ (m^{-1})),
     main = "Diffuse attenuation spectrum (0 and 10 m measurements)")

## ----jerlov-------------------------------------------------------------------
x0m_Jerlov <- x0m_W[350, 700]
lam   <- x0m_Jerlov$lambda
Kd_II <- jerlov_Kd("II", lam)

specs <- propagate_spectrum(x0m_Jerlov, Kd_II, from = 0,
                            to = c(0, 5, 10, 20, 50))
plot(specs, main = "Depth-propagated spectra — Jerlov Type II")

## ----band---------------------------------------------------------------------
bi <- band_irradiance(x0m_Jerlov, Kd_II,
                      depths     = c(0, 5, 10, 20, 50),
                      lambda_min = 400, lambda_max = 500)
knitr::kable(bi, digits = 3,
             col.names = c("Depth (m)", "Blue-band irradiance (W m⁻²)"))

## ----photic-------------------------------------------------------------------
Kd_PAR_mean <- mean(Kd_II[lam >= 400 & lam <= 700])
photic_z    <- photic_depth(Kd_PAR_mean)
cat(sprintf("1%% light level (Jerlov Type II): %.1f m\n", photic_z))

