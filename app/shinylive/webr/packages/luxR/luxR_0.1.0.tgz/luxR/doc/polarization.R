## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(
  message = FALSE, warning = FALSE,
  fig.width = 7, fig.height = 4
)
library(luxR)

## ----refraction---------------------------------------------------------------
refracted_solar_angle(c(0, 30, 60, 90))   # in-water solar zenith (deg)

## ----dop-zenith---------------------------------------------------------------
vz  <- seq(0, 90, by = 2)
res <- underwater_polarization(view_zenith = vz, sun_zenith = 0, depth = 1)

plot(res$scattering_angle, res$dop, type = "l", lwd = 2, col = "steelblue4",
     xlab = "Scattering angle from sun (deg)",
     ylab = "Degree of polarization",
     main = "Underwater DoP vs angle from the sun (near surface)")
abline(v = 90, lty = 3, col = "grey50")

## ----dop-depth----------------------------------------------------------------
depths <- seq(0, 100, by = 2)
dz <- underwater_polarization(view_zenith = 90, sun_zenith = 0,
                              depth = depths, dop_max = 0.4, dop_asym = 0.03)

plot(depths, dz$dop, type = "l", lwd = 2, col = "firebrick",
     xlab = "Depth (m)", ylab = "Degree of polarization",
     main = "DoP at the 90-degree band vs depth")
abline(h = 0.03, lty = 3, col = "grey50")

## ----aop----------------------------------------------------------------------
underwater_polarization(view_zenith = c(0, 45, 90), view_azimuth = 0,
                        sun_zenith = 30, sun_azimuth = 0, depth = 5)

